package beanNational;

public class SupplierSemBeanNc {
	
	private String supplierName;
	private String year;
	private String month;
	private double value;
	public String getSupplierName() {
		return supplierName;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public double getValue() {
		return value;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setValue(double value) {
		this.value = value;
	}

	
	
}
