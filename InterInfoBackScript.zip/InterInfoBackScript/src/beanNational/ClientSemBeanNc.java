package beanNational;

public class ClientSemBeanNc {

	private String client;
	private String year;
	private String month;
	private double value;
	public String getClient() {
		return client;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public double getValue() {
		return value;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setValue(double value) {
		this.value = value;
	}
	
	
}
