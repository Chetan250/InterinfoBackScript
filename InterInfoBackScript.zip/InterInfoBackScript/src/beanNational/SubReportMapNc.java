package beanNational;

public class SubReportMapNc {
	private int reportId;
	private int subReportId;
	private String timeBy;
	
	

	public int getReportId() {
		return reportId;
	}
	public int getSubReportId() {
		return subReportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public void setSubReportId(int subReportId) {
		this.subReportId = subReportId;
	}
	public String getTimeBy() {
		return timeBy;
	}
	

	public void setTimeBy(String timeBy) {
		this.timeBy = timeBy;
	}
	
	
	

}
