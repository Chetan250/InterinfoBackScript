package beanNational;

public class SupplierYearBeanNc {
	private String supplierName;
	private String year;
	private double value;
	public String getSupplierName() {
		return supplierName;
	}
	public String getYear() {
		return year;
	}
	public double getValue() {
		return value;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setValue(double value) {
		this.value = value;
	}
	
	

}
