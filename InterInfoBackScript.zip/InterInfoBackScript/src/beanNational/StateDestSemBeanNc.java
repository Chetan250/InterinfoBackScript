package beanNational;

public class StateDestSemBeanNc {
	
	private String state;
	private String year;
	private String month;
	private double value;
	public String getState() {
		return state;
	}
	public String getYear() {
		return year;
	}
	public String getMonth() {
		return month;
	}
	public double getValue() {
		return value;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public void setValue(double value) {
		this.value = value;
	}
	
	

}
