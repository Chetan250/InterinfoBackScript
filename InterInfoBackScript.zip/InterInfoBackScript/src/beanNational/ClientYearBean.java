package beanNational;

public class ClientYearBean {
	private String client;
	private String year;
	private double value;
	public String getClient() {
		return client;
	}
	public String getYear() {
		return year;
	}
	public double getValue() {
		return value;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	

}
