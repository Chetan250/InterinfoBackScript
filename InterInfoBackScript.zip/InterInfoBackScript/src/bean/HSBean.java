package bean;

public class HSBean {
		private String FRACCION;
		private String ANIO;
		private String MES;
		private int USD;
		public String getFRACCION() {
			return FRACCION;
		}
		public String getANIO() {
			return ANIO;
		}
		public String getMES() {
			return MES;
		}
		public int getUSD() {
			return USD;
		}
		public void setFRACCION(String fRACCION) {
			FRACCION = fRACCION;
		}
		public void setANIO(String aNIO) {
			ANIO = aNIO;
		}
		public void setMES(String mES) {
			MES = mES;
		}
		public void setUSD(int uSD) {
			USD = uSD;
		}


	}



