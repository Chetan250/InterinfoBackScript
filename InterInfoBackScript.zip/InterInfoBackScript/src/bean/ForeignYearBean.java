package bean;

public class ForeignYearBean {

	private String supplier;
	private String year;
	private double MONTO;
	public String getSupplier() {
		return supplier;
	}
	public String getYear() {
		return year;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	
}
