package bean;

public class HSCodeYearBean {
	private String year;
	private double MONTO;
	private String FRACCION;
	public String getYear() {
		return year;
	}
	public double getMONTO() {
		return MONTO;
	}
	public String getFRACCION() {
		return FRACCION;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	public void setFRACCION(String fRACCION) {
		FRACCION = fRACCION;
	}
	
	

}
