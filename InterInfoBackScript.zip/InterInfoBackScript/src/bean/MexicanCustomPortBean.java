package bean;

public class MexicanCustomPortBean {
	private String maxicanCompany;
	private String border;
	private double MONTO;
	public String getMaxicanCompany() {
		return maxicanCompany;
	}
	public String getBorder() {
		return border;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setMaxicanCompany(String maxicanCompany) {
		this.maxicanCompany = maxicanCompany;
	}
	public void setBorder(String border) {
		this.border = border;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	

}
