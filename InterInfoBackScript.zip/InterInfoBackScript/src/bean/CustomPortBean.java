package bean;

public class CustomPortBean {
	private String border;
	private String supplier;
	private double MONTO;
	public String getBorder() {
		return border;
	}
	public String getSupplier() {
		return supplier;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setBorder(String border) {
		this.border = border;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	

}
