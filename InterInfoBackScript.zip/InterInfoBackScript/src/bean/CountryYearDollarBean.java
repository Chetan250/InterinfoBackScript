package bean;

public class CountryYearDollarBean {
	private String origDest;
	private String year;
	private double MONTO;
	public String getOrigDest() {
		return origDest;
	}
	public String getYear() {
		return year;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setOrigDest(String origDest) {
		this.origDest = origDest;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	

}
