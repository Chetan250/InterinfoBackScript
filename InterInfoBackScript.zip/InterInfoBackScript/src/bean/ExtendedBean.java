package bean;

public class ExtendedBean {
	
	private String IE;
	private String FECENTRA;
	private String AGENTE;
	private String NOMBRE_ADUANA;
	private String TIPO;
	private String REGIMEN;
	private String PEDIMENTO;
	private String DIA;
	private String MES;
	
	private String Ano;
	private String FRACCION;
	private String DESCRIPTION;
	private String RFC;
	private String RAZON;
	private String DIRECCION;
	private String CP;
	private String MUNICIPIO;
	private String ESTADO;
	private String RUTA;
	private String PAIS_RUTA;
	private String ORIGEN;
	private String PAIS_ORIGEN;
	private String MEDIO;
	private String MED_COMER;
	private String CANT_COMER;
	private String PESO_BRUTO;
	private String CANTIDAD;
	private String UNIDAD_DE_MEDIDA;
	private String MONTO;
	private String USD;
	private String FP_ADVAL1;
	private String IMPUESTO;
	private String FP_TRAMAD;
	private String IMP_TRAMAD;
	private String FP_CCOMP1;
	private String CUOTACOMP;
	private String FP_IVA1;
	private String IMP_IVA1;
	private String FP_ISAN;
	private String IMP_ISAN;
	private String FP_IEPS;
	private String IMP_IEPS;
	private String IMP_FLETE;
	private String IPM_SECURO;
	private String TIPO_CAMBIO;
	private String FECPAGO;
	private String VALORCOM;
	private String VALORAGR;
	private String DEST_ORIG;
	private String TASA_ADV;
	private String TASA_IVA;
	private String VINCULA;
	private String METVALORA;
	private String TASAIEPS;
	private String  PRIM_PERM;
	private String TPRIM_PERM;
	private String SEGU_PERM;
	private String TSEGU_PERM;
	private String TERC_PERM;
	private String TTERC_PERM;
	private String FP_RECAR;
	private String IPM_RECAR;
	private String TAXNUMBER;
	private String NAME;
	private String ADDRESS;
	private String CITY;
	private String STATE;
	private String ZIP;
	
	
	
	public String getIE() {
		return IE;
	}
	public String getFECENTRA() {
		return FECENTRA;
	}
	public String getAGENTE() {
		return AGENTE;
	}
	public String getNOMBRE_ADUANA() {
		return NOMBRE_ADUANA;
	}
	public String getTIPO() {
		return TIPO;
	}
	public String getREGIMEN() {
		return REGIMEN;
	}
	public String getPEDIMENTO() {
		return PEDIMENTO;
	}
	public String getDIA() {
		return DIA;
	}
	public String getMES() {
		return MES;
	}
	public void setIE(String iE) {
		IE = iE;
	}
	public void setFECENTRA(String fECENTRA) {
		FECENTRA = fECENTRA;
	}
	public void setAGENTE(String aGENTE) {
		AGENTE = aGENTE;
	}
	public void setNOMBRE_ADUANA(String nOMBRE_ADUANA) {
		NOMBRE_ADUANA = nOMBRE_ADUANA;
	}
	public void setTIPO(String tIPO) {
		TIPO = tIPO;
	}
	public void setREGIMEN(String rEGIMEN) {
		REGIMEN = rEGIMEN;
	}
	public void setPEDIMENTO(String pEDIMENTO) {
		PEDIMENTO = pEDIMENTO;
	}
	public void setDIA(String dIA) {
		DIA = dIA;
	}
	public void setMES(String mES) {
		MES = mES;
	}
	public String getAno() {
		return Ano;
	}
	public String getFRACCION() {
		return FRACCION;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public String getRFC() {
		return RFC;
	}
	public String getRAZON() {
		return RAZON;
	}
	public String getDIRECCION() {
		return DIRECCION;
	}
	public String getCP() {
		return CP;
	}
	public String getMUNICIPIO() {
		return MUNICIPIO;
	}
	public String getESTADO() {
		return ESTADO;
	}
	public String getRUTA() {
		return RUTA;
	}
	public String getPAIS_RUTA() {
		return PAIS_RUTA;
	}
	public String getORIGEN() {
		return ORIGEN;
	}
	public String getPAIS_ORIGEN() {
		return PAIS_ORIGEN;
	}
	public String getMEDIO() {
		return MEDIO;
	}
	public String getMED_COMER() {
		return MED_COMER;
	}
	public String getCANT_COMER() {
		return CANT_COMER;
	}
	public String getPESO_BRUTO() {
		return PESO_BRUTO;
	}
	public String getCANTIDAD() {
		return CANTIDAD;
	}
	public String getUNIDAD_DE_MEDIDA() {
		return UNIDAD_DE_MEDIDA;
	}
	public String getMONTO() {
		return MONTO;
	}
	public String getUSD() {
		return USD;
	}
	public String getFP_ADVAL1() {
		return FP_ADVAL1;
	}
	public String getIMPUESTO() {
		return IMPUESTO;
	}
	public String getFP_TRAMAD() {
		return FP_TRAMAD;
	}
	public String getIMP_TRAMAD() {
		return IMP_TRAMAD;
	}
	public String getFP_CCOMP1() {
		return FP_CCOMP1;
	}
	public String getCUOTACOMP() {
		return CUOTACOMP;
	}
	public String getFP_IVA1() {
		return FP_IVA1;
	}
	public String getIMP_IVA1() {
		return IMP_IVA1;
	}
	public String getFP_ISAN() {
		return FP_ISAN;
	}
	public String getIMP_ISAN() {
		return IMP_ISAN;
	}
	public String getFP_IEPS() {
		return FP_IEPS;
	}
	public String getIMP_IEPS() {
		return IMP_IEPS;
	}
	public String getIMP_FLETE() {
		return IMP_FLETE;
	}
	public String getIPM_SECURO() {
		return IPM_SECURO;
	}
	public String getTIPO_CAMBIO() {
		return TIPO_CAMBIO;
	}
	public String getFECPAGO() {
		return FECPAGO;
	}
	public String getVALORCOM() {
		return VALORCOM;
	}
	public String getVALORAGR() {
		return VALORAGR;
	}
	public String getDEST_ORIG() {
		return DEST_ORIG;
	}
	public String getTASA_ADV() {
		return TASA_ADV;
	}
	public String getTASA_IVA() {
		return TASA_IVA;
	}
	public String getVINCULA() {
		return VINCULA;
	}
	public String getMETVALORA() {
		return METVALORA;
	}
	public String getTASAIEPS() {
		return TASAIEPS;
	}
	public String getPRIM_PERM() {
		return PRIM_PERM;
	}
	public String getTPRIM_PERM() {
		return TPRIM_PERM;
	}
	public String getSEGU_PERM() {
		return SEGU_PERM;
	}
	public String getTSEGU_PERM() {
		return TSEGU_PERM;
	}
	public String getTERC_PERM() {
		return TERC_PERM;
	}
	public String getTTERC_PERM() {
		return TTERC_PERM;
	}
	public String getFP_RECAR() {
		return FP_RECAR;
	}
	public String getIPM_RECAR() {
		return IPM_RECAR;
	}
	public String getTAXNUMBER() {
		return TAXNUMBER;
	}
	public String getNAME() {
		return NAME;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public String getCITY() {
		return CITY;
	}
	public String getSTATE() {
		return STATE;
	}
	public String getZIP() {
		return ZIP;
	}
	public void setAno(String ano) {
		Ano = ano;
	}
	public void setFRACCION(String fRACCION) {
		FRACCION = fRACCION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public void setRFC(String rFC) {
		RFC = rFC;
	}
	public void setRAZON(String rAZON) {
		RAZON = rAZON;
	}
	public void setDIRECCION(String dIRECCION) {
		DIRECCION = dIRECCION;
	}
	public void setCP(String cP) {
		CP = cP;
	}
	public void setMUNICIPIO(String mUNICIPIO) {
		MUNICIPIO = mUNICIPIO;
	}
	public void setESTADO(String eSTADO) {
		ESTADO = eSTADO;
	}
	public void setRUTA(String rUTA) {
		RUTA = rUTA;
	}
	public void setPAIS_RUTA(String pAIS_RUTA) {
		PAIS_RUTA = pAIS_RUTA;
	}
	public void setORIGEN(String oRIGEN) {
		ORIGEN = oRIGEN;
	}
	public void setPAIS_ORIGEN(String pAIS_ORIGEN) {
		PAIS_ORIGEN = pAIS_ORIGEN;
	}
	public void setMEDIO(String mEDIO) {
		MEDIO = mEDIO;
	}
	public void setMED_COMER(String mED_COMER) {
		MED_COMER = mED_COMER;
	}
	public void setCANT_COMER(String cANT_COMER) {
		CANT_COMER = cANT_COMER;
	}
	public void setPESO_BRUTO(String pESO_BRUTO) {
		PESO_BRUTO = pESO_BRUTO;
	}
	public void setCANTIDAD(String cANTIDAD) {
		CANTIDAD = cANTIDAD;
	}
	public void setUNIDAD_DE_MEDIDA(String uNIDAD_DE_MEDIDA) {
		UNIDAD_DE_MEDIDA = uNIDAD_DE_MEDIDA;
	}
	public void setMONTO(String mONTO) {
		MONTO = mONTO;
	}
	public void setUSD(String uSD) {
		USD = uSD;
	}
	public void setFP_ADVAL1(String fP_ADVAL1) {
		FP_ADVAL1 = fP_ADVAL1;
	}
	public void setIMPUESTO(String iMPUESTO) {
		IMPUESTO = iMPUESTO;
	}
	public void setFP_TRAMAD(String fP_TRAMAD) {
		FP_TRAMAD = fP_TRAMAD;
	}
	public void setIMP_TRAMAD(String iMP_TRAMAD) {
		IMP_TRAMAD = iMP_TRAMAD;
	}
	public void setFP_CCOMP1(String fP_CCOMP1) {
		FP_CCOMP1 = fP_CCOMP1;
	}
	public void setCUOTACOMP(String cUOTACOMP) {
		CUOTACOMP = cUOTACOMP;
	}
	public void setFP_IVA1(String fP_IVA1) {
		FP_IVA1 = fP_IVA1;
	}
	public void setIMP_IVA1(String iMP_IVA1) {
		IMP_IVA1 = iMP_IVA1;
	}
	public void setFP_ISAN(String fP_ISAN) {
		FP_ISAN = fP_ISAN;
	}
	public void setIMP_ISAN(String iMP_ISAN) {
		IMP_ISAN = iMP_ISAN;
	}
	public void setFP_IEPS(String fP_IEPS) {
		FP_IEPS = fP_IEPS;
	}
	public void setIMP_IEPS(String iMP_IEPS) {
		IMP_IEPS = iMP_IEPS;
	}
	public void setIMP_FLETE(String iMP_FLETE) {
		IMP_FLETE = iMP_FLETE;
	}
	public void setIPM_SECURO(String iPM_SECURO) {
		IPM_SECURO = iPM_SECURO;
	}
	public void setTIPO_CAMBIO(String tIPO_CAMBIO) {
		TIPO_CAMBIO = tIPO_CAMBIO;
	}
	public void setFECPAGO(String fECPAGO) {
		FECPAGO = fECPAGO;
	}
	public void setVALORCOM(String vALORCOM) {
		VALORCOM = vALORCOM;
	}
	public void setVALORAGR(String vALORAGR) {
		VALORAGR = vALORAGR;
	}
	public void setDEST_ORIG(String dEST_ORIG) {
		DEST_ORIG = dEST_ORIG;
	}
	public void setTASA_ADV(String tASA_ADV) {
		TASA_ADV = tASA_ADV;
	}
	public void setTASA_IVA(String tASA_IVA) {
		TASA_IVA = tASA_IVA;
	}
	public void setVINCULA(String vINCULA) {
		VINCULA = vINCULA;
	}
	public void setMETVALORA(String mETVALORA) {
		METVALORA = mETVALORA;
	}
	public void setTASAIEPS(String tASAIEPS) {
		TASAIEPS = tASAIEPS;
	}
	public void setPRIM_PERM(String pRIM_PERM) {
		PRIM_PERM = pRIM_PERM;
	}
	public void setTPRIM_PERM(String tPRIM_PERM) {
		TPRIM_PERM = tPRIM_PERM;
	}
	public void setSEGU_PERM(String sEGU_PERM) {
		SEGU_PERM = sEGU_PERM;
	}
	public void setTSEGU_PERM(String tSEGU_PERM) {
		TSEGU_PERM = tSEGU_PERM;
	}
	public void setTERC_PERM(String tERC_PERM) {
		TERC_PERM = tERC_PERM;
	}
	public void setTTERC_PERM(String tTERC_PERM) {
		TTERC_PERM = tTERC_PERM;
	}
	public void setFP_RECAR(String fP_RECAR) {
		FP_RECAR = fP_RECAR;
	}
	public void setIPM_RECAR(String iPM_RECAR) {
		IPM_RECAR = iPM_RECAR;
	}
	public void setTAXNUMBER(String tAXNUMBER) {
		TAXNUMBER = tAXNUMBER;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public void setCITY(String cITY) {
		CITY = cITY;
	}
	public void setSTATE(String sTATE) {
		STATE = sTATE;
	}
	public void setZIP(String zIP) {
		ZIP = zIP;
	}
	
	
	
	
	
	
	
}
