package bean;

public class MexicanSupplierBean {
	private String mexicanCompany;
	private String supplier;
	private double MONTO;
	public String getMexicanCompany() {
		return mexicanCompany;
	}
	public String getSupplier() {
		return supplier;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setMexicanCompany(String mexicanCompany) {
		this.mexicanCompany = mexicanCompany;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	

}
