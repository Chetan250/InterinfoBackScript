package bean;

public class CustomsYearDollarBean {
	private String border;
	private String year;
	private double MONTO;
	public String getBorder() {
		return border;
	}
	public String getYear() {
		return year;
	}
	public double getMONTO() {
		return MONTO;
	}
	public void setBorder(String border) {
		this.border = border;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public void setMONTO(double mONTO) {
		MONTO = mONTO;
	}
	
	

}
